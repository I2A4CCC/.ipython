nums = [1, 2, 3, 4]
sum = 1
for num in range(1, len(nums) + 1):
    sum = sum * num

print(sum)