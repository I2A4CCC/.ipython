def numbers(even):
    even = int(input('enter a randome number: '))
    if even % 2 == 0:
        return True
    return False 