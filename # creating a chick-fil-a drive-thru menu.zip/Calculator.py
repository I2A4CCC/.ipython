# Write code below 💖

# creating a calculator by defining five functions with parameters (a, b)

# adding
def add(a, b):
  total = a + b
  return total
print(add(float(input("Enter a random number to add: ")), float(input('Enter another number to add: '))))

# subtracting
def subtract(a, b):
  total_2 = a - b
  return total_2
print(subtract(float(input('Enter a random number to subtract: ')), float(input('Enter another number to subtract: '))))

# multiplying 
def multiply(a, b):
  total_3 = a * b
  return total_3
print(multiply(float(input('Enter a random number to  multiply: ')), float(input('Enter another number to multiply: '))))

# dividing 
def divide(a, b):
  total_4 = a / b
  return total_4
print(divide(float(input('Enter a ranodm number to devide: ')), float(input('Enter another random number: '))))

# exponent form
def exp(a, b):
  total_5 = a ** b
  return total_5
print(exp(float(input('Enter a random number to get it exponet form: ')), float(input('Enter another number: '))))



